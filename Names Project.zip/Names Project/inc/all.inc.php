<?php

require __DIR__ . '/db-connect.inc.php';
require __DIR__ . '/functions.inc.php';
require __DIR__ . '/names.inc.php';
